<?php
$wsclient_version = '1.1';
?>
